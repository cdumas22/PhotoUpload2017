﻿namespace PhotoUpload.ViewModels
{
    public class CropInformation
    {
        public byte[] Bytes { get; internal set; }
    }
}